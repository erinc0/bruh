package com.cis2818.project4.dataModel

data class weatherDataModel(
    val maxTemp_f: Double,
    val minTemp_f: Double,
    val avgTemp_f: Double,
    val avgHumidity: Int,
    val dailyRainChance: Int,
    val dailySnowChance: Int
) {
    //Only for HelloText as a test, Comment out when you add more!
    override fun toString(): String {
        return "MaxTemp: $maxTemp_f°F, MinTemp: $minTemp_f°F, AvgTemp: $avgTemp_f°F, Humidity: $avgHumidity%, RainChance: $dailyRainChance%, SnowChance: $dailySnowChance%"
    }
}