package com.cis2818.project4

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.annotation.NonNull
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.cis2818.project4.dataModel.weatherDataModel
import com.cis2818.project4.databinding.ActivityMainBinding
import org.json.JSONObject
import java.net.URL
import java.util.ArrayList
import javax.net.ssl.HttpsURLConnection

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {


        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        @NonNull //Activity main causing issues without this
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)




        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        fetchWeatherData().start()//Starts connection
    }

    val weatherDetailsList: ArrayList<weatherDataModel> = ArrayList()

    //Fetch Data creates a thread runs in the background so app doesn't freeze
    fun fetchWeatherData(): Thread {
        return Thread {
            try {
                //TO DO, REPLACE days= and q= to days=${inputData} & q=${someData}.
                // Days changes forecast(up to 14 days), and q is location data,
                // check -> https://www.weatherapi.com/docs/ (Request Param section) for details

                //Check url for API example! It really helps to know what your looking at!
                val url =
                    URL("https://api.weatherapi.com/v1/forecast.json?key=299c989699ea435a90d184057240612&q=48390&days=7&aqi=no&alerts=no")
                val connection = url.openConnection() as HttpsURLConnection //Open HTTPS Connection to server!

                //Response code 200 == Connection Success!
                if (connection.responseCode == 200) {
                    val result = connection.inputStream.bufferedReader().use { it.readText() }
                    val jsonResponse = JSONObject(result) //Get RestAPI response
                    val forecast = jsonResponse.getJSONObject("forecast").getJSONArray("forecastday") //Get forecastday array


                    for(i in 0 until forecast.length()){
                        val forecastDay = forecast.getJSONObject(i) //Get forecast element at array position i (I.e forecast day 0, 1, ...)
                        val day = forecastDay.getJSONObject("day") //Get data for the day from forecastDay (forecast -> forecastday -> day{objData})

                        //Accesses day's object data at element[i] for each day :3
                        val maxTemp_f = day.getDouble("maxtemp_f")
                        val minTemp_f = day.getDouble("mintemp_f")
                        val avgTemp_f = day.getDouble("avgtemp_f")
                        val avgHumidity = day.getInt("avghumidity")
                        val dailyRainChance = day.getInt("daily_chance_of_rain")
                        val dailySnowChance = day.getInt("daily_chance_of_snow")

                        //Create an instance of my data class for each day(Template)
                        val weatherDetails = weatherDataModel(maxTemp_f, minTemp_f, avgTemp_f, avgHumidity, dailyRainChance, dailySnowChance)
                        weatherDetailsList.add(weatherDetails)
                    }


                    //Runs on the ui thread to update ui, add silly bindings here :3
                    runOnUiThread {
                        binding.HelloText.text = "Todays Weather: ${weatherDetailsList}"
                        val button = findViewById<Button>(R.id.button)
                        button.setOnClickListener{
                            val intent= Intent(this, MainActivity2::class.java)
                            startActivity(intent)
                        }

                    }

                } else { //Connection failed text(Add a seperate invisible text that displays when an error occurs)
                    runOnUiThread {
                        binding.HelloText.text = "Connection Failed"
                    }
                }
            } catch (e: Exception) { //Log-cat exception, type WeatherFetch into filters to find error if it occurs!
                Log.e("WeatherFetch", "Error fetching data", e)
                runOnUiThread {
                    binding.HelloText.text = "Error Occurred"
                }
            }
        }

    }//end fetchWeatherData
}//end MainActivity
